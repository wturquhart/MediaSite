# frame — PHP video-sharing site

A PHP video-sharing site with a responsive dark UI, native HTML5 video player, user accounts, administrator portal, MySQL persistence, local video storage, and FFmpeg transcoding.

## Install on a server

The web installer handles application setup only; it does **not** install or configure Linux packages, PHP-FPM, Nginx, MySQL itself, DNS, firewall rules, or HTTPS. Provision those services first. Ubuntu 24.04 ships PHP 8.3; install the required packages with:

```bash
sudo apt update
sudo apt install nginx mysql-server php8.3-fpm php8.3-mysql php8.3-mbstring php8.3-xml php8.3-cli ffmpeg certbot python3-certbot-nginx
```

The app requires PHP 8.0+, PDO MySQL, and `fileinfo` (provided by PHP's common modules on Ubuntu). Put the app files in `/var/www/frame/public` and set that as Nginx's document root; do not make `/var/www/frame` itself public, because it contains private site data. Serve PHP over HTTPS. Configure PHP-FPM for large uploads and transcoding, and give its `www-data` user write access only to the private data directory.

Create an empty database and a dedicated MySQL user with privileges limited to that database. For example, from a privileged MySQL session (replace the sample password with a strong secret):

```sql
CREATE DATABASE frame CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'frame_app'@'127.0.0.1' IDENTIFIED BY 'replace-with-a-strong-secret';
GRANT ALL PRIVILEGES ON frame.* TO 'frame_app'@'127.0.0.1';
```

Copy the PHP application files into `/var/www/frame/public`. Set up private storage with `sudo install -d -o www-data -g www-data -m 0750 /var/www/frame/mediasite-data /var/www/frame/mediasite-data/uploads`. A starting Nginx site config for Ubuntu 24/PHP 8.3 is:

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name your-domain.example;
    root /var/www/frame/public;
    index index.php;
    client_max_body_size 512M;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ^~ /uploads/ {
        alias /var/www/frame/mediasite-data/uploads/;
        autoindex off;
        add_header X-Content-Type-Options nosniff always;
    }

    location ~* \.(sqlite|db|json|log)$ {
        deny all;
    }

    location ~ /\. {
        deny all;
    }

    location ~ \.php$ {
        try_files $uri =404;
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.3-fpm.sock;
        fastcgi_param HTTPS $https if_not_empty;
        fastcgi_read_timeout 1800s;
    }
}
```

Enable the site, run `sudo nginx -t`, reload Nginx, confirm DNS points to the VPS and ports 80/443 are open, then obtain HTTPS with `sudo certbot --nginx -d your-domain.example`. Certbot will add TLS settings and redirect HTTP to HTTPS. The `/uploads/` alias exposes only the upload directory; keep the private data directory outside the document root.

Set PHP-FPM upload/transcode limits in `/etc/php/8.3/fpm/php.ini` (`upload_max_filesize = 500M`, `post_max_size = 512M`, `max_execution_time = 1800`, `max_input_time = 1800`) and restart PHP-FPM. To enable FFmpeg conversion, add `env[FRAME_REQUIRE_TRANSCODE] = 1` to the pool config and restart it.

For remote setup, generate a one-time key with `openssl rand -hex 32`, add `env[FRAME_INSTALL_KEY] = <your-key>` to `/etc/php/8.3/fpm/pool.d/www.conf`, and restart PHP-FPM. Then visit `https://your-domain.example/install.php`, enter that key, the MySQL connection, and first administrator details. The installer tests the connection, initializes its tables, creates the administrator, and saves database credentials in a mode-restricted JSON file in private storage. On success it signs you in and opens the admin portal. Remove the `FRAME_INSTALL_KEY` setting and restart PHP-FPM after setup. The installer locks itself after setup; keep `install.php` in place to show that setup is complete, or remove it after verifying the site works.

Use HTTPS for installation because database credentials are submitted in the setup form. The installer only initializes an **empty** application database and refuses to overwrite a database that already contains application data. Existing deployments should not run it against their active database.

## Features and limits

- `install.php` provides the initial database and administrator setup; `login.php`, `register.php`, `logout.php`, and `admin.php` are the regular application entry points.
- The player is the browser's native HTML5 `<video controls>` player. Uploaded videos can be re-encoded to H.264/AAC MP4 with FFmpeg when `FRAME_REQUIRE_TRANSCODE=1` is configured in PHP-FPM.
- MySQL persistence uses InnoDB transactions and UTF-8. Existing JSON/SQLite migration support remains for configured legacy deployments; the web installer is for a fresh database.
- Session cookies are HTTP-only, secure under HTTPS, and SameSite; forms use CSRF tokens. Account creation, sign-in, and uploads are rate-limited.
- Uploads require a signed-in account. Limits are 500 MB per source file, 10 videos and 5 GB per account, with a default 50 GB site limit. The site administrator can pause uploads, manage accounts, update site settings, and hide or restore videos.
- Uploaded media defaults to a private directory outside the document root. The Nginx `/uploads/` alias described above serves only that media directory; never map it to PHP execution.

## Local development

Create an empty MySQL database and a dedicated user as described above, then run PHP's built-in server for local testing only:

```powershell
$env:FRAME_DATA_DIR = Join-Path $PWD 'mediasite-data'
php -S 127.0.0.1:8080 -t .\mediasite
```

Open `http://localhost:8080/install.php` to configure the database and create the administrator. The installer permits HTTP only from localhost; never use the built-in server for public deployment. For local uploaded-video playback, configure `FRAME_UPLOAD_DIR` and map its contents under `/uploads/` in your local web server.

## Operations

Back up the MySQL database (for example, `mysqldump --single-transaction frame`) and the private uploads directory to separate storage, and test restores. Monitor free disk space, database and web-server logs, TLS renewal, and upload growth. For higher availability or traffic, use managed MySQL and object storage/CDN.

This is a self-hosting baseline, not a guarantee of production readiness for every use case. Email verification, password recovery, transactional email, automated moderation, malware scanning, and managed backups are not included. Review privacy, retention, legal, and abuse requirements before inviting the public.
